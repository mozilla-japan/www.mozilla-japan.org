diff -b -w -d -u -r checkout/mozilla/browser/locales/ja-JP/	browser/locales/ja-JP/ > browser.ja-JP.diff
diff -b -w -d -u -r checkout/mozilla/toolkit/locales/ja-JP/	toolkit/locales/ja-JP/ > toolkit.ja-JP.diff
diff -b -w -d -u -r checkout/mozilla/browser/locales/ja-JPM/	browser/locales/ja-JPM/ > browser.ja-JPM.diff
diff -b -w -d -u -r checkout/mozilla/toolkit/locales/ja-JPM/	toolkit/locales/ja-JPM/ > toolkit.ja-JPM.diff


